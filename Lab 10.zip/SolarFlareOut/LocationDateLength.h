#ifndef LOCATIONDATELENGTH_H
#define LOCATIONDATELENGTH_H

#include "Date.h"
#include "Location.h"

#endif

#ifndef LOCATION_CPP
#define LOCATION_CPP

#endif
